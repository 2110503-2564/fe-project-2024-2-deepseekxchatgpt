"use client"
import BookingList from '@/components/BookingList'
export default function myBookingPage() {
    return (
        <main>
            <BookingList/>
        </main>
    )
}