import Registeration from '@/components/Registeration'
export default function Register() {
  return (
    <Registeration/>
  )
}